/* CHANGE THESE TO YOUR OWN VALUES IF USING --mysql */
#define MYSQL_HOST "192.168.4.6"
#define MYSQL_USER "dump1090"
#define MYSQL_PASS "YOUR_PASSWORD_HERE"
#define MYSQL_DB   "dump1090"

/* THE TABLE STRUCTURE CAN BE FOUND IN tools/create_database.sql */

