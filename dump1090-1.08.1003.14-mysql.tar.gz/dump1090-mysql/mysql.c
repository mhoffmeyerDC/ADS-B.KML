#include "dump1090.h"

/* Write aircraft data to a MySQL Database */
void modesFeedMySQL(struct modesMessage *mm, struct aircraft *a) {

    MYSQL *conn;
    conn = mysql_init(NULL);
    mysql_real_connect(conn, MYSQL_HOST, MYSQL_USER, MYSQL_PASS, MYSQL_DB, 0, NULL, 0);

    char msgFlights[1000], *p = msgFlights;

    /* we flill a live 'flights' table - update old data */
    /* DF 0 (Short Air to Air, ACAS has: altitude, icao) */
    if (mm->msgtype == 0) {
         snprintf(p, 999, "INSERT INTO flights (icao, alt, df, msgs) VALUES ('%06X', '%02X', '%d', '%ld') "
                          "ON DUPLICATE KEY UPDATE "
                          "icao=VALUES(icao), alt=VALUES(alt), df=VALUES(df), msgs=VALUES(msgs)",
                           mm->addr, mm->altitude, mm->msgtype, a->messages);
         if (mysql_query(conn, p)) {
              printf("DF0 MySQL Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
         exit(1);
         }
    }
    /* DF 4/20 (Surveillance (roll call) Altitude has: altitude, icao, flight status, DR, UM) */
    /* TODO flight status, DR, UM */
    if (mm->msgtype == 4 || mm->msgtype == 20){
         snprintf(p, 999, "INSERT INTO flights (icao, alt, df, msgs) VALUES ('%06X', '%d', '%d', '%ld') "
                          "ON DUPLICATE KEY UPDATE icao=VALUES(icao), alt=VALUES(alt), df=VALUES(df), msgs=VALUES(msgs)",
                           mm->addr, a->altitude, mm->msgtype, a->messages);
         if (mysql_query(conn, p)) {
               printf("DF4/20 MySQL Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
         exit(1);
         }
    }
    /* DF 5/21 (Surveillance (roll call) IDENT Reply, has: alt, icao, flight status, DR, UM, squawk) */
    if (mm->msgtype == 5 || mm->msgtype == 21) {
         snprintf(p, 999, "INSERT INTO flights (icao, alt, squawk, df, msgs) VALUES ('%06X', '%d', '%d', '%d', '%ld') "
                          "ON DUPLICATE KEY UPDATE icao=VALUES(icao), alt=VALUES(alt), squawk=VALUES(squawk), df=VALUES(df), "
                          "msgs=VALUES(msgs)",
                           mm->addr, mm->altitude, mm->modeA, mm->msgtype, a->messages);
           if (mysql_query(conn, p)) {
                printf("DF 5/21 MySQL Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
        exit(1);
        }
    }
    /* DF 11 */
    if (mm->msgtype == 11) {
         snprintf(p, 999, "INSERT INTO flights (icao, df, msgs) VALUES ('%06X', '%d', '%ld') "
                          "ON DUPLICATE KEY UPDATE icao=VALUES(icao), df=VALUES(df), msgs=VALUES(msgs)",
                           mm->addr, mm->msgtype, a->messages);
         if (mysql_query(conn, p)) {
                printf("DF11 MySQL Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
         exit(1);
         }
         //mysql_close(conn);
    }
    /* DF17 *with or without position data */
    if (mm->msgtype == 17) {
         snprintf(p, 999, "INSERT INTO flights (df, flight, airline, icao, alt, vr, lat, lon, speed, heading, msgs) "
                          "VALUES ('%d', '%s', '%3s', '%06X', '%d', '%d', '%1.5f', '%1.5f', '%d', '%d', '%ld') "
                          "ON DUPLICATE KEY UPDATE "
                          "df=VALUES(df), flight=VALUES(flight), airline=VALUES(airline), icao=VALUES(icao), alt=VALUES(alt), vr=VALUES(vr), "
                          "lat=VALUES(lat), lon=VALUES(lon), speed=VALUES(speed), heading=VALUES(heading), msgs=VALUES(msgs)", 
                           mm->msgtype, a->flight, a->flight, mm->addr, mm->altitude, mm->vert_rate, a->lat, a->lon, 
                           a->speed, a->track, a->messages);
         if (mysql_query(conn, p)) {
              printf("Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
         exit(1);
         }
    }
    /* update 'tracks' table if we have position data (df 17 extended squitter with position) */
    if (mm->msgtype == 17 && mm->metype >= 9 && mm->metype <= 18) {
         if (a->lat != 0 && a->lon != 0) {
              snprintf(p, 999, "INSERT INTO tracks (icao, alt, lat , lon) VALUES ('%06X','%d','%1.5f','%1.5f')",
                                         mm->addr, mm->altitude, a->lat, a->lon);
                   if (mysql_query(conn, p)) {
                        printf("Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
                   exit(1);
                   }
         }
    }
    mysql_close(conn);
}
